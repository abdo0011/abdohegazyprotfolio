// All factual content lives here so it's easy to review and update
// without touching component markup. Nothing here is invented —
// it mirrors the original approved copy exactly.

export const personal = {
  name: 'Abdo Elrhman Hegazy',
  role: 'Cybersecurity Student · Penetration Testing Trainee',
  phone: '01210736292',
  linkedinUrl: 'https://www.linkedin.com/in/abdo-hegazy-034ab62b6',
  linkedinHandle: 'abdo-hegazy-034ab62b6',
}

export const navLinksPrimary = [
  { href: '#about', label: 'About' },
  { href: '#skills', label: 'Skills' },
  { href: '#projects', label: 'Labs' },
  { href: '#certifications', label: 'Certifications' },
  { href: '#writeups', label: 'Write-ups' },
  { href: '#contact', label: 'Contact' },
]

export const navLinksMobile = [
  { href: '#about', label: 'About' },
  { href: '#education', label: 'Education' },
  { href: '#skills', label: 'Skills' },
  { href: '#tools', label: 'Tools' },
  { href: '#projects', label: 'Labs' },
  { href: '#certifications', label: 'Certifications' },
  { href: '#journey', label: 'Journey' },
  { href: '#writeups', label: 'Write-ups' },
  { href: '#contact', label: 'Contact' },
]

export const aboutFocusList = [
  'Strong grounding in networking fundamentals and TCP/IP',
  'Hands-on practice with reconnaissance and enumeration techniques',
  'Applied learning in web application security concepts',
  'Regular lab work on platforms like TryHackMe',
  'Continuous, structured learning through the DEPI program',
]

export const education = {
  institution: 'October Technological University',
  department: 'Department of Networks / Networking',
}

export const training = {
  program: 'Digital Egypt Pioneers Initiative (DEPI)',
  track: 'Penetration Tester track, delivered through training organization ODD.',
}

// level: 'learning' | 'practicing' | 'comfortable'
export const skills = [
  { name: 'TCP/IP', level: 'practicing' },
  { name: 'Networking Fundamentals', level: 'comfortable' },
  { name: 'Network Enumeration', level: 'practicing' },
  { name: 'Reconnaissance', level: 'practicing' },
  { name: 'Vulnerability Assessment', level: 'learning' },
  { name: 'Nmap', level: 'practicing' },
  { name: 'Wireshark', level: 'practicing' },
  { name: 'Burp Suite', level: 'learning' },
  { name: 'Metasploit', level: 'learning' },
  { name: 'HTTP', level: 'comfortable' },
  { name: 'SQL Injection', level: 'learning' },
  { name: 'SQLmap', level: 'learning' },
  { name: 'OWASP Concepts', level: 'learning' },
  { name: 'Linux', level: 'practicing' },
  { name: 'Kali Linux', level: 'practicing' },
  { name: 'Windows', level: 'comfortable' },
  { name: 'Virtual Machines', level: 'comfortable' },
]

export const tools = ['Nmap', 'Wireshark', 'Burp Suite', 'Metasploit', 'SQLmap', 'Linux', 'Kali Linux', 'TryHackMe']

export const projects = [
  {
    tag: 'Lab',
    title: 'Network Enumeration Lab',
    description: 'Practical network reconnaissance and enumeration using Nmap and related networking techniques.',
    stack: ['Nmap', 'TCP/IP', 'Enumeration'],
  },
  {
    tag: 'Lab',
    title: 'Web Application Security Lab',
    description: 'Hands-on practice with HTTP, Burp Suite, web reconnaissance, and common web security concepts.',
    stack: ['Burp Suite', 'HTTP', 'Web Recon'],
  },
  {
    tag: 'Practice',
    title: 'SQL Injection Practice',
    description: 'Educational lab work focused on understanding SQL Injection and using SQLmap in controlled environments.',
    stack: ['SQLmap', 'SQL Injection'],
  },
  {
    tag: 'Ongoing',
    title: 'TryHackMe Security Labs',
    description: 'Hands-on cybersecurity learning through controlled labs and practical security challenges.',
    stack: ['TryHackMe', 'Linux', 'Kali Linux'],
  },
]

// status: 'completed' | 'ongoing'
export const certifications = [
  {
    name: 'Network+',
    issuer: 'Infosec / Coursera',
    status: 'completed',
    statusLabel: 'Completed',
  },
  {
    name: 'Digital Egypt Pioneers Initiative — Penetration Tester',
    issuer: 'DEPI · Training organization: ODD',
    status: 'ongoing',
    statusLabel: 'Currently training',
  },
  {
    name: 'TryHackMe',
    issuer: 'Hands-on security practice',
    status: 'ongoing',
    statusLabel: 'Ongoing learning',
  },
]

export const journey = [
  { title: 'Networking', description: 'Building a solid foundation in how networks and protocols work.' },
  { title: 'Linux & Kali', description: 'Getting comfortable operating in Linux and Kali Linux environments.' },
  { title: 'Network Security', description: 'Learning how networks are secured and where weaknesses appear.' },
  { title: 'Reconnaissance & Enumeration', description: 'Practicing information gathering with tools like Nmap and Wireshark.' },
  { title: 'Web Security', description: 'Exploring web application concepts with Burp Suite and HTTP fundamentals.' },
  { title: 'Penetration Testing', description: 'Applying skills in the DEPI Penetration Tester track.' },
  { title: 'Continuous Practice', description: 'Reinforcing everything through ongoing labs on TryHackMe and beyond.' },
]

// Add a new object here whenever a real write-up is published.
export const writeups = [
  { name: 'Nmap Basics' },
  { name: 'Network Enumeration' },
  { name: 'SQL Injection Concepts' },
  { name: 'Burp Suite Basics' },
  { name: 'Linux for Penetration Testing' },
  { name: 'OWASP Concepts' },
]
