import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import About from './components/About.jsx'
import Education from './components/Education.jsx'
import Skills from './components/Skills.jsx'
import Tools from './components/Tools.jsx'
import Projects from './components/Projects.jsx'
import Certifications from './components/Certifications.jsx'
import Journey from './components/Journey.jsx'
import Writeups from './components/Writeups.jsx'
import Contact from './components/Contact.jsx'
import Footer from './components/Footer.jsx'

export default function App() {
  return (
    <>
      <div className="grid-bg" aria-hidden="true" />

      <Navbar />

      <main>
        <Hero />
        <About />
        <Education />
        <Skills />
        <Tools />
        <Projects />
        <Certifications />
        <Journey />
        <Writeups />
        <Contact />
      </main>

      <Footer />
    </>
  )
}
