import { personal } from '../data/content.js'
import ProfilePhoto from './ProfilePhoto.jsx'

export default function Hero() {
  return (
    <section className="hero" id="hero">
      <div className="wrap hero-grid">
        <div>
          <div className="terminal-line">
            whoami
            <span className="cursor" aria-hidden="true" />
          </div>
          <h1>
            Abdo Elrhman
            <br />
            Hegazy
          </h1>
          <span className="role">{personal.role}</span>
          <p className="lede">
            Networks student at October Technological University, currently training in the Digital
            Egypt Pioneers Initiative&rsquo;s Penetration Tester track with ODD. I build my practical
            security skills through networking fundamentals, hands-on labs, and continuous, deliberate
            practice.
          </p>
          <div className="hero-actions">
            <a className="btn btn-primary" href={personal.linkedinUrl} target="_blank" rel="noopener noreferrer">
              View LinkedIn
            </a>
            <a className="btn" href="#contact">
              Get in touch
            </a>
            <a className="btn" href="#projects">
              View labs
            </a>
          </div>
        </div>

        <div className="hero-photo-col">
          <ProfilePhoto />
        </div>
      </div>
    </section>
  )
}
