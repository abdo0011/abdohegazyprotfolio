import { certifications } from '../data/content.js'

export default function Certifications() {
  return (
    <section id="certifications">
      <div className="wrap">
        <div className="eyebrow">certifications &amp; learning</div>
        <h2 className="section-title">Certifications &amp; learning status</h2>

        <div className="cert-list">
          {certifications.map((cert) => (
            <div className="cert-row" key={cert.name}>
              <div>
                <div className="name">{cert.name}</div>
                <div className="issuer">{cert.issuer}</div>
              </div>
              <span className={`status-badge${cert.status === 'ongoing' ? ' ongoing' : ''}`}>
                {cert.statusLabel}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
