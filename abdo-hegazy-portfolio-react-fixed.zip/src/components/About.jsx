import { aboutFocusList } from '../data/content.js'
import Reveal from './Reveal.jsx'

export default function About() {
  return (
    <section id="about">
      <div className="wrap about-grid">
        <Reveal>
          <div className="eyebrow">about</div>
          <h2 className="section-title">Learning security from the network up</h2>
          <p className="section-lede">
            I&rsquo;m a Networks student at October Technological University, building a foundation in
            how systems actually communicate before specializing further. Alongside my studies, I&rsquo;m
            training in the DEPI Penetration Tester track, where I practice reconnaissance, enumeration,
            and vulnerability assessment in controlled lab environments.
          </p>
        </Reveal>

        <Reveal>
          <ul className="focus-list">
            {aboutFocusList.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  )
}
