import { personal } from '../data/content.js'

export default function Footer() {
  return (
    <footer>
      <div className="wrap footer-inner">
        <div>
          <div className="name mono">{personal.name}</div>
          <div className="role">{personal.role}</div>
        </div>
        <a className="btn" href={personal.linkedinUrl} target="_blank" rel="noopener noreferrer">
          LinkedIn ↗
        </a>
      </div>
    </footer>
  )
}
