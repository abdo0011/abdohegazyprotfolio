import { personal } from '../data/content.js'

export default function Contact() {
  return (
    <section id="contact">
      <div className="wrap">
        <div className="eyebrow">contact</div>
        <h2 className="section-title">Let&rsquo;s connect</h2>
        <p className="section-lede">
          Open to conversations about cybersecurity, networking, and penetration testing training.
        </p>

        <div className="contact-card">
          <div className="contact-item">
            <div className="label">NAME</div>
            <div className="value">{personal.name}</div>
          </div>
          <div className="contact-item">
            <div className="label">PHONE</div>
            <div className="value">{personal.phone}</div>
          </div>
          <div className="contact-item">
            <div className="label">LINKEDIN</div>
            <a className="value" href={personal.linkedinUrl} target="_blank" rel="noopener noreferrer">
              {personal.linkedinHandle} ↗
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
