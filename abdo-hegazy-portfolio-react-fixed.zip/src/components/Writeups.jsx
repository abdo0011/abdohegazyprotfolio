import { writeups } from '../data/content.js'

export default function Writeups() {
  return (
    <section id="writeups">
      <div className="wrap">
        <div className="eyebrow">write-ups &amp; knowledge</div>
        <h2 className="section-title">Notes &amp; write-ups</h2>
        <p className="section-lede">
          A space for technical write-ups as I document what I learn. Add an entry in
          <code className="inline"> src/data/content.js</code> for each new post.
        </p>

        <div className="writeups-grid">
          {writeups.map((writeup) => (
            <div className="writeup-card" key={writeup.name}>
              <div className="name">{writeup.name}</div>
              <div className="soon">Coming soon</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
