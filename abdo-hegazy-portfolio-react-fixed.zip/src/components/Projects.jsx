import { projects } from '../data/content.js'
import Reveal from './Reveal.jsx'

export default function Projects() {
  return (
    <section id="projects">
      <div className="wrap">
        <div className="eyebrow">labs &amp; practice</div>
        <h2 className="section-title">Projects &amp; lab work</h2>
        <p className="section-lede">
          Practice work from controlled lab environments and structured training — not unauthorized
          testing or client engagements.
        </p>

        <div className="projects-grid">
          {projects.map((project) => (
            <Reveal className="card project-card" key={project.title}>
              <span className="project-tag">{project.tag}</span>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <div className="project-stack">
                {project.stack.map((item) => (
                  <span key={item}>{item}</span>
                ))}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
