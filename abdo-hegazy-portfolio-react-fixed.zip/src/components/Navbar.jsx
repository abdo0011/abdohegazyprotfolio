import { useState } from 'react'
import { personal, navLinksPrimary, navLinksMobile } from '../data/content.js'

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)

  const closeMenu = () => setMenuOpen(false)

  return (
    <header className="nav">
      <div className="wrap nav-inner">
        <a href="#hero" className="brand">
          <span className="dot" />
          abdo@hegazy<span style={{ color: 'var(--text-faint)' }}>:~$</span>
        </a>

        <nav className="links" aria-label="Primary">
          {navLinksPrimary.map((link) => (
            <a key={link.href} href={link.href}>
              {link.label}
            </a>
          ))}
        </nav>

        <div className="nav-actions">
          <a className="btn" href={personal.linkedinUrl} target="_blank" rel="noopener noreferrer">
            LinkedIn
          </a>
          <a className="btn btn-primary" href="#contact">
            Contact
          </a>
        </div>

        <button
          className="hamburger"
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
          aria-controls="mobileMenu"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>
      </div>

      <div id="mobileMenu" className={`mobile-menu${menuOpen ? ' open' : ''}`}>
        {navLinksMobile.map((link) => (
          <a key={link.href} href={link.href} onClick={closeMenu}>
            {link.label}
          </a>
        ))}
      </div>
    </header>
  )
}
