import { education, training } from '../data/content.js'
import Reveal from './Reveal.jsx'

export default function Education() {
  return (
    <section id="education">
      <div className="wrap">
        <div className="eyebrow">background</div>
        <h2 className="section-title">Education &amp; current training</h2>

        <div className="two-col" style={{ marginTop: 32 }}>
          <Reveal className="card">
            <span className="status-badge">Education</span>
            <h3 style={{ fontSize: 19 }}>{education.institution}</h3>
            <p style={{ color: 'var(--text-dim)', fontSize: 14, marginTop: 8 }}>{education.department}</p>
          </Reveal>

          <Reveal className="card" id="training">
            <span className="status-badge ongoing">Currently training</span>
            <h3 style={{ fontSize: 19 }}>{training.program}</h3>
            <p style={{ color: 'var(--text-dim)', fontSize: 14, marginTop: 8 }}>{training.track}</p>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
