import useReveal from '../hooks/useReveal.js'

/**
 * Wraps children in a div that fades/slides in once visible.
 * `as` lets a caller render a different tag (e.g. "section") if needed.
 */
export default function Reveal({ children, className = '', as: Tag = 'div', ...rest }) {
  const ref = useReveal()
  return (
    <Tag ref={ref} className={`reveal ${className}`.trim()} {...rest}>
      {children}
    </Tag>
  )
}
