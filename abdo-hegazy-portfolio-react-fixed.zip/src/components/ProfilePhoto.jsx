import { useState } from 'react'

// Looked up from /public, so this resolves to /images/profile.jpg at runtime.
const PROFILE_PHOTO_SRC = '/images/profile.jpg'

/**
 * Renders the real photo when public/images/profile.jpg exists.
 * If the file is missing (or fails to load for any reason), it falls
 * back to the same neutral placeholder used before — never a generated
 * or stand-in photo of a person.
 *
 * To add your real photo: place a file named "profile.jpg" inside
 * the "public/images" folder. No code changes are needed.
 */
export default function ProfilePhoto() {
  const [imageFailed, setImageFailed] = useState(false)

  return (
    <div className="photo-frame">
      <div className="photo-inner">
        {!imageFailed ? (
          <img
            src={PROFILE_PHOTO_SRC}
            alt="Abdo Elrhman Hegazy"
            onError={() => setImageFailed(true)}
          />
        ) : (
          <div className="photo-placeholder">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
              <circle cx="12" cy="8" r="4" />
              <path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8" />
            </svg>
            <span>profile.jpg</span>
          </div>
        )}
      </div>
    </div>
  )
}
