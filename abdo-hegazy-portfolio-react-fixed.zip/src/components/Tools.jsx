import { tools } from '../data/content.js'

export default function Tools() {
  return (
    <section id="tools">
      <div className="wrap">
        <div className="eyebrow">toolkit</div>
        <h2 className="section-title">Tools I work with</h2>

        <div className="tools-grid">
          {tools.map((tool) => (
            <div className="tool-chip" key={tool}>
              {tool}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
