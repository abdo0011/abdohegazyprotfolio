import { skills } from '../data/content.js'

const LEVEL_LABEL = {
  learning: 'Learning',
  practicing: 'Practicing',
  comfortable: 'Comfortable',
}

export default function Skills() {
  return (
    <section id="skills">
      <div className="wrap">
        <div className="eyebrow">technical skills</div>
        <h2 className="section-title">Where I&rsquo;m building strength</h2>
        <p className="section-lede">
          Skill levels here reflect an active learning journey, not professional-grade expertise.
        </p>

        <div className="skills-grid">
          {skills.map((skill) => (
            <div className="skill-item" key={skill.name}>
              <span className="name">{skill.name}</span>
              <span className={`level ${skill.level}`}>{LEVEL_LABEL[skill.level]}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
