import { journey } from '../data/content.js'

export default function Journey() {
  return (
    <section id="journey">
      <div className="wrap">
        <div className="eyebrow">learning journey</div>
        <h2 className="section-title">How I&rsquo;m progressing</h2>

        <div className="timeline">
          {journey.map((step) => (
            <div className="timeline-item" key={step.title}>
              <h4>{step.title}</h4>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
