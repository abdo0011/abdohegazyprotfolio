import { useEffect, useRef } from 'react'

/**
 * Adds the "in" class to an element once it scrolls into view,
 * reproducing the original .reveal / .reveal.in fade-up animation.
 * Falls back gracefully if IntersectionObserver isn't available.
 */
export default function useReveal() {
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    if (!('IntersectionObserver' in window)) {
      el.classList.add('in')
      return
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in')
            io.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )

    io.observe(el)
    return () => io.disconnect()
  }, [])

  return ref
}
