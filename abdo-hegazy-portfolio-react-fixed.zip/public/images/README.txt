Place your real profile photo in this folder as:

    profile.jpg

The site looks for it at /images/profile.jpg (public/images/profile.jpg).
No code changes are needed — the Hero section's ProfilePhoto component
(src/components/ProfilePhoto.jsx) automatically shows this photo once
it's present, and falls back to the existing neutral placeholder if the
file is missing.
